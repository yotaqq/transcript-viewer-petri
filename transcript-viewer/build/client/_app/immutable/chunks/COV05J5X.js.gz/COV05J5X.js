import{I as a}from"./DDSnUQRm.js";a();

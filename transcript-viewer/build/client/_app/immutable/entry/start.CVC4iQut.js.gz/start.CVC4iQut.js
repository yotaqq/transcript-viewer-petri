import{l as o,a as r}from"../chunks/BE0jUqnW.js";export{o as load_css,r as start};
